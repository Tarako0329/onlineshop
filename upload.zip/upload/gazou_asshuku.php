<?php
// タイムアウトを防ぐ（大量の画像がある場合のため）
set_time_limit(300);

/**
 * 前述の画像最適化関数（バックアップ作成付き）
 */
function backupAndOptimizeImage($filePath) {
    if (!file_exists($filePath)) return false;

    // パスの分解
    $pathParts = pathinfo($filePath);
    
    // すでにバックアップファイルなら処理しない
    if (strpos($pathParts['filename'], '_BK') !== false) return false;

    $backupPath = $pathParts['dirname'] . '/' . $pathParts['filename'] . '_BK.' . $pathParts['extension'];

    // バックアップが既に存在する場合はスキップ（上書き防止）
    if (!file_exists($backupPath)) {
        if (!copy($filePath, $backupPath)) return false;
    }

    $imageInfo = getimagesize($filePath);
    if (!$imageInfo) return false;

    $width = $imageInfo[0];
    $height = $imageInfo[1];
    $type = $imageInfo[2];

    $maxWidth = 1200;
    if ($width > $maxWidth) {
        $newWidth = $maxWidth;
        $newHeight = floor($height * ($maxWidth / $width));
    } else {
        $newWidth = $width;
        $newHeight = $height;
    }

    switch ($type) {
        case IMAGETYPE_JPEG: $source = imagecreatefromjpeg($filePath); break;
        case IMAGETYPE_PNG:  $source = imagecreatefrompng($filePath); break;
        default: return false;
    }

    $newImage = imagecreatetruecolor($newWidth, $newHeight);
    if ($type == IMAGETYPE_PNG) {
        imagealphablending($newImage, false);
        imagesavealpha($newImage, true);
    }

    imagecopyresampled($newImage, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

    $success = false;
    switch ($type) {
        case IMAGETYPE_JPEG: $success = imagejpeg($newImage, $filePath, 80); break;
        case IMAGETYPE_PNG:  $success = imagepng($newImage, $filePath, 6); break;
    }

    imagedestroy($source);
    imagedestroy($newImage);

    return $success;
}

// --- メイン処理 ---

echo "<h2>画像一括最適化を開始します...</h2>";

// 対応する拡張子を指定してファイルを取得
$files = glob("*.{jpg,jpeg,png,JPG,JPEG,PNG}", GLOB_BRACE);

$count = 0;
foreach ($files as $file) {
    // 自分自身やバックアップファイルを除外する二重チェック
    if (strpos($file, '_BK') !== false) continue;

    echo "処理中: {$file} ... ";
    
    if (backupAndOptimizeImage($file)) {
        echo "<span style='color:green;'>成功</span><br>";
        $count++;
    } else {
        echo "<span style='color:red;'>スキップまたは失敗</span><br>";
    }
}

echo "<hr><p>合計 {$count} 枚の画像を処理しました。</p>";
?>